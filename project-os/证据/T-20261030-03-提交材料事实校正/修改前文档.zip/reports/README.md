# 报告索引

> 更新：2026-10-25。已有报告按原文归类，移动不重新认证其中的实验成绩。当前状态见 [项目状态](../project-os/项目状态.md)。

| 类别 | 材料 | 应如何理解 |
|---|---|---|
| 演示讲解 | [成功示例](demos/demo_success.md)、[拒答示例](demos/demo_failure.md) | 历史定位演示说明，不能代替当前完整修复验收 |
| 实验记录 | [Demo 消融](experiments/ablation_demo_smoke.md)、[原始演示数据](experiments/_demo_raw.json) | 历史运行材料；部分指标沿用旧名，使用前核对版本和口径 |
| 披露材料 | [第三方披露](compliance/third_party_disclosure.md)、[资源使用清单](compliance/open_source_checklist.md) | 已有快照，资源状态仍需逐项核验；文件内旧路径按迁移清单查询 |
| 历史运行报告 | [demo_final](archive/demo_final.md)、[demo_final2](archive/demo_final2.md) | 保留原文件名和内容以对应旧证据包，不再称为当前“最终版” |
| 历史评估 | [2026-10-03 改进评估](archive/improvement_eval.md)、[旧清单校验记录](archive/validate_sample_manifest_test.md) | 仅说明当时结果；原控制台日志保留在 `archive/_stage6_console.log` |
| 后续运行输出 | `runs/`（按命令生成） | 建议名称含日期和任务 ID，保存 JSON 与 Markdown，并说明代码版本、模型来源、预算及验收状态 |

## 使用规则

1. 本轮没有产生新的算法对照或真实模型自主修复报告，不能从目录整理推断效果提升。
2. `verify=PASS` 与 `repair=VERIFIED` 含义不同，当前验证规则见 [统一修复验收](../docs/05_测试/统一修复验收.md)。
3. 历史报告原文与演示仓库 `.replens/` 证据快照保留；不编辑其字节来更新旧路径或指标。
4. 新的基线、消融与真实定位汇总默认写 `reports/runs/`；披露生成器写 `reports/compliance/`。对已有披露材料重新生成前应保留需引用的快照。
5. 原文中提及但当前缺失的 tqdm/pypdf 修复报告、loguru 汇总及模型报告，不因建立分类目录而变成已存在。

全部旧→新路径和原始哈希见 [迁移清单](../project-os/证据/T-20261025-01-目录与资料整理/路径迁移.json)。
