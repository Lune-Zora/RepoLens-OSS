# RepoLens-OSS

> 面向开源贡献的新手 Issue 定位、补丁生成与验证工作台。

核心原则：**让模型的每一个判断都能被代码证据和测试结果证伪或证实。**

核心包 `replens/` 零第三方依赖（纯 Python 标准库）。无模型时可以完成索引、检索、测试和少量规则修复；复杂 Issue 的根因分析和通用补丁需要接入大模型。

## 快速开始

```bash
# 1. 导入仓库（识别许可证/依赖/测试框架）
python -m replens init examples/demo_repo

# 2. 构建代码结构索引（AST + SQLite FTS5）
python -m replens index examples/demo_repo

# 3. 检索定位 + 证据
python -m replens search examples/demo_repo \
    --issue "date string with surrounding whitespace fails to parse"

# 4. 生成修改计划
python -m replens plan examples/demo_repo \
    --issue "date string with surrounding whitespace fails to parse"

# 5. 完整闭环（定位→计划→自动补丁→测试验证→报告）
#    无模型也可演示 strip 规则兜底；复杂 Issue 请配置本地模型
python -m replens run examples/demo_repo \
    --issue "date string with surrounding whitespace fails to parse" \
    --test-cmd "python -m unittest discover -s tests" --auto-patch \
    --acceptance-suite examples/acceptance/demo.json --require-verified

# 6. 跑定位评测（文件 hit@k/MRR@k、函数短名、符号起始行、拒答计数）
python -m replens eval examples/demo_repo --dataset eval/datasets/dataset.json

# 7. 基线对比（random / grep / RepoLens BM25 / RepoLens 混合）
python eval/baselines.py examples/demo_repo --dataset eval/datasets/dataset.json

# 8. 混合检索（BM25+语义向量 RRF；需 REPLENS_EMBED_BASE_URL/KEY 或本地 fastembed）
python -m replens search examples/demo_repo \
    --issue "date string with surrounding whitespace fails to parse" --hybrid

# 9. 合规披露（第三方依赖与开源许可）
python -m replens compliance .

# 10. 单元测试（当前交付包含标准库测试；CI 可用 pytest 收集 unittest 用例）
#     覆盖 patchgen / compliance / report / executor 补丁 / testgen / 行为回归测试 等
python -m pytest tests/ -q

# 11. unified diff 补丁同样支持（无需 git，内置 hunk 解析器，兼容 CRLF）
python -m replens run examples/demo_repo \
    --issue "date string with surrounding whitespace fails to parse" \
    --patch eval/reference_patches/demo_strip.diff \
    --test-cmd "pytest tests/test_parser.py"
python -m pytest tests/ -q
```

> 索引默认按「源码指纹」自动复用，改动源码后无需手动重建；可用 `--force-reindex` 强制重建。

上述完整闭环会生成 JSON Schema 2.0 证据包，将独立验收的完整冻结内容和前后结果保存在包中。用运行输出的实际目录替换 `<证据包路径>`，可在保留原始源码的条件下重放全部套件：

```powershell
python -m replens verify examples/demo_repo --provenance "<证据包路径>" --require-verified --format json --output reports/runs/demo_replay.json
```

结果区分材料核验、重放一致性和修复结论；重放 PASS 不会把 UNVERIFIED 自动变成 VERIFIED。格式、哈希定义及旧包兼容见 [证据包格式与重放](docs/05_测试/证据包格式与重放.md)。

## Web 可视化工作台

零构建（vanilla JS）的可视化界面，把上述命令封装为按钮操作：

```bash
pip install -e .[web]
uvicorn web.app:app --reload
# 打开 http://127.0.0.1:8000
```

提供：仓库选择/导入、索引构建、Issue 定位与修改计划、完整闭环（自动补丁 + 测试验证 +
Markdown 报告下载、证据包重放）、评测集指标、合规披露、评测集挖掘，以及 LLM / 语义向量环境状态提示。

## 目录与阅读入口

```text
replens/       核心索引、检索、补丁、执行、验收与报告
web/           可选 Web API 与静态前端
tests/         项目自身测试
examples/      演示仓库与仓库外的独立验收材料
eval/          评测脚本及 datasets/training/mined/reference_patches
scripts/       数据准备、训练与辅助校验脚本
reports/       demos/experiments/compliance/archive 与后续 runs 输出
docs/          按需求、架构、接口、测试、运维归类的文档
project-os/    当前状态、维护决策、历史任务与验收证据
```

- 当前完成情况与验证边界：[项目状态](project-os/项目状态.md)。
- 后续任务与验收条件：[ROADMAP](ROADMAP.md)。
- 文档导航：[文档地图](docs/文档地图.md)。
- 数据用途与使用命令：[评测材料索引](eval/README.md)。
- 当前可查报告与历史材料：[报告索引](reports/README.md)。

## 模型配置与启动

普通 CLI 和 Web **不会自动读取 `.env`**。在 Windows PowerShell 中，先在项目根目录设置：

```powershell
$env:REPLENS_LLM_BASE_URL = 'http://127.0.0.1:11434/v1'
$env:REPLENS_LLM_MODEL = 'qwen2.5-coder:1.5b'
$env:REPLENS_LLM_N_CANDIDATES = '4'
$env:REPLENS_REQUIRE_LLM = '1'
$env:REPLENS_LLM_PROVIDER = ''
$env:REPLENS_LLM_API_KEY = ''
Remove-Item Env:OPENAI_API_KEY -ErrorAction SilentlyContinue
python scripts/llm_env.py
python -m uvicorn web.app:app --host 127.0.0.1 --port 8000
```

本地服务需已经启动且安装了指定模型。上述变量仅作用于当前终端及随后启动的子进程。
GET `/models` 自检或 Web“已配置”都不表示推理已经成功；需要实际运行计划/修复确认。
完整的 CLI、Web、`.env`、兼容接口与离线切换步骤见 [模型配置与启动](docs/06_运维/模型配置与启动.md)。

正式 Demo 证据使用 `python scripts/run_llm_demo.py`。该脚本可以读取 `.env`，始终禁止规则兜底，
通过标准 CLI `run` / `verify` 保存调用轨迹、实际调用/重试次数、源码快照和重放结果。
可用 `--output-dir <新目录>` 指定交付位置，已有目录不覆盖，详见 [LLM 证据说明](reports/llm/README.md)。
云端或自建兼容服务使用同一组 `REPLENS_*` 环境变量，地址、模型名和 key 按实际服务填写。
未配置地址且允许回退时，普通入口使用有限规则；严格模式不会把规则补丁记为模型成功。

## 真实开源仓库评测与修复（国赛加分项）

在 tqdm 与 pypdf 两个真实开源项目的历史 bug 上构造了第二评测集
（eval/datasets/real_dataset_tqdm.json、eval/datasets/real_dataset_pypdf.json），
并按 SWE-bench 方法论（buggy 父提交 + 测试补丁 + 源码补丁）完成定位评测与修复验证：

- 真实仓库结果必须在仓库副本、commit、测试补丁和日志均存在时才可引用；当前公开交付中的 `repos/` 和 `reports/` 仍需补齐。
- 演示仓库的离线基线和改进结果见 `reports/archive/improvement_eval.md`，其中明确区分文档记录、标准库实测和模型实测。

消融实验（BM25-only vs +调用图 vs +语义向量）见 docs/05_测试/消融实验.md 与 eval/ablation.py。

详见 docs/05_测试/真实仓库评测.md 与 docs/06_运维/社区贡献.md（PR-ready 补丁在 eval/reference_patches/contrib/）。

真实历史 Bug 需要先恢复有效 buggy 基线、验证上游 Gold、补冻结的独立行为验收，再生成并跨工作树重放证据。首个 tqdm reset(inf) 样本已通过这条链路：3 条同步主测试和 2 条独立验收，第二工作树的材料和重放均 PASS、修复结论 VERIFIED。来源、测试配置与验证边界见 [单样本真实 Bug 恢复](docs/05_测试/单样本真实Bug恢复.md)。该流程的 Gold 验证不计入模型自主修复成功率。

## 文档

- 系统设计与技术选型：[docs/02_架构/设计方案.md](docs/02_架构/设计方案.md)
- 核验标准与验收效果：[docs/05_测试/验收规划.md](docs/05_测试/验收规划.md)
