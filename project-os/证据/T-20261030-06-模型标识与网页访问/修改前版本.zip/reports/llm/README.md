# 严格模型 Demo 证据

正式入口为 `python scripts/run_llm_demo.py`。它读取环境变量 / `.env`，强制
`REPLENS_REQUIRE_LLM=1`，通过标准 CLI `run`（包含计划生成）和 `verify` 完成验证。
不会额外跑一份独立计划，也不会用规则补丁代替模型结果。

```powershell
python scripts/run_llm_demo.py
# 或指定一个尚不存在、位于 Demo 仓库之外的输出目录
python scripts/run_llm_demo.py --output-dir 'E:\osspj\参赛提交-20261030\验证\新的唯一目录'
```

输出包含：

- `summary.json`：源码提交、工作区状态、配置、实际命令和退出码、调用次数、实际重试轮次与模型用量。
- `model-requests/`：每次模型请求、原始响应、解析结果或错误、阶段、候选轮次和耗时。
- `source-snapshot.zip`、`source-files-before.json` / `source-files-after.json`、工作区差异：本次代码与运行输入快照，可包含尚未提交的实际变更。
- `report.json` / `report.md`：计划、采用的补丁及三个测试套件的前后结果。
- `provenance/`：本次 CLI 实际返回的 Schema 2.0 包；不会猜测“最新目录”或选用旧包。
- `replay.json`：对交付副本执行标准 CLI verify 的最终结论。
- `run.*.txt` / `verify.*.txt`：原始控制台输出。
- `delivery-manifest.json`：上述交付文件的 SHA-256。

只有 run、完整材料、严格模型来源、verify、调用记录和源码一致性全部满足要求，
脚本才返回 0。任何阶段失败均返回非零，保留已经产生的证据，不能因缺包或重放失败而显示完成。
重复执行使用新目录，不覆盖已有记录。精确调用次数是模型调用尝试次数；网络或解析失败也会计数。
Token 用量来自服务响应，不作为独立计费核验；未返回用量时会明确标记不可用。

普通 CLI / Web 不会自动读取 `.env`；需要先在终端设置模型环境变量。
若单独使用标准 CLI 并需要调用记录，可设置进程环境变量 `REPLENS_LLM_TRACE_DIR`。
当前调用记录覆盖 OpenAI 兼容 HTTP 客户端；本演示脚本使用该路径，不宣称覆盖 transformers 后端。
记录中不写鉴权头，配置的 API key 会脱敏；请求内包含任务代码和模型输出，分享前应复核内容。

## 2026-10-30 完整证据

本轮正式结果：[验证说明](demo-llm-20261030-022020/验证说明.md)、[调用及命令汇总](demo-llm-20261030-022020/summary.json)、[重放](demo-llm-20261030-022020/replay.json)。
严格模型 run 和 verify 均退出 0；模型调用共 5 次（计划 1 + 补丁 4），实际重试 0 次。
源码 ZIP 131 文件哈希一致，同机新目录解压后再次重放 VERIFIED。完整回归 235 passed / 81 subtests。
此次未运行全新虚拟环境或跨机器实验，也未验证真实复杂 Bug 的模型修复。

## 历史结果纠正

`demo-llm-20261029-200720` 的证据包和 replay 均保留原始字节，不修改历史记录。
该次计划来源是模型，但 `provenance/report.json` 的 patch_note 明确说明最终采用了规则 strip 补丁。
所以该次 VERIFIED 只能证明规则修复与重放通过，不能记为模型自主修复成功。

2026-10-30 01:26 的外部交付目录 `standard-cli-20261030-012622` 已通过标准 CLI 严格模型修复和重放，
但未记录逐次模型请求，因此它是有效的功能验证，不能被称为完整调用轨迹证据。
后续使用本脚本生成的新目录补齐调用记录，不倒填或覆盖该次历史材料。

## 能力边界

内置 Demo 源码注释包含 strip 修复提示，成功主要证明模型调用、补丁生成、测试验收和重放链路。
它不代表真实复杂 Bug 已被模型修复，不代表跨机器验证或多次稳定性实验。
report 中 NOT_CHECKED / NOT_RUN 是打包时快照；后续重放结果以 replay.json 为准。
单个模型失败案例不能推出“必须 7B+ 或 LoRA 才能解决”的结论。
