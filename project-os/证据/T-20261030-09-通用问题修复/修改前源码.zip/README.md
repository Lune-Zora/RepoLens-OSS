# RepoLens-OSS

> 面向开源贡献的新手 Issue 定位、补丁生成与验证工作台。

核心原则：**让修改结论附上代码证据与测试结果，供复核。**

核心包 `replens/` 零第三方依赖（纯 Python 标准库）。无模型时可以完成索引、检索、测试和少量规则修复；复杂 Issue 的根因分析和通用补丁需要接入大模型。

完整交付基线：Python 3.10及以上；本机实测为3.10.11。GitHub Actions配置了3.10—3.12，尚无本次托管运行结果。

## 快速开始

```bash
# 1. 导入仓库（识别许可证/依赖/测试框架）
python -m replens init examples/demo_repo

# 2. 构建代码结构索引（AST + SQLite FTS5）
python -m replens index examples/demo_repo

# 3. 检索定位 + 证据
python -m replens search examples/demo_repo \
    --issue "date string with surrounding whitespace fails to parse"

# 4. 生成修改计划
python -m replens plan examples/demo_repo \
    --issue "date string with surrounding whitespace fails to parse"

# 5. 完整闭环（定位→计划→自动补丁→测试验证→报告）
#    无模型也可演示 strip 规则兜底；复杂 Issue 请配置本地模型
python -m replens run examples/demo_repo \
    --issue "date string with surrounding whitespace fails to parse" \
    --test-cmd "python -m unittest discover -s tests" --auto-patch \
    --acceptance-suite examples/acceptance/demo.json --require-verified

# 6. 跑定位评测（文件 hit@k/MRR@k、函数短名、符号起始行、拒答计数）
python -m replens eval examples/demo_repo --dataset eval/datasets/dataset.json

# 7. 基线对比（random / grep / RepoLens BM25 / RepoLens 混合）
python eval/baselines.py examples/demo_repo --dataset eval/datasets/dataset.json

# 8. 混合检索（BM25+语义向量 RRF；需 REPLENS_EMBED_BASE_URL/KEY 或本地 fastembed）
python -m replens search examples/demo_repo \
    --issue "date string with surrounding whitespace fails to parse" --hybrid

# 9. 合规披露（第三方依赖与开源许可）
python -m replens compliance .

# 10. 单元测试（当前交付包含标准库测试；CI 可用 pytest 收集 unittest 用例）
#     覆盖 patchgen / compliance / report / executor 补丁 / testgen / 行为回归测试 等
python -m pytest tests/ -q

# 11. unified diff 补丁同样支持（无需 git，内置 hunk 解析器，兼容 CRLF）
python -m replens run examples/demo_repo \
    --issue "date string with surrounding whitespace fails to parse" \
    --patch eval/reference_patches/demo_strip.diff \
    --test-cmd "pytest tests/test_parser.py"
python -m pytest tests/ -q
```

> 索引默认按路径、mtime 与大小构成的元数据指纹自动复用（不是内容哈希），改动源码后无需手动重建；可用 `--force-reindex` 强制重建。

上述完整闭环会生成 JSON Schema 2.0 证据包，将独立验收的完整冻结内容和前后结果保存在包中。用运行输出的实际目录替换 `<证据包路径>`，可在保留原始源码的条件下重放全部套件：

```powershell
python -m replens verify examples/demo_repo --provenance "<证据包路径>" --require-verified --format json --output reports/runs/demo_replay.json
```

结果区分材料核验、重放一致性和修复结论；重放 PASS 不会把 UNVERIFIED 自动变成 VERIFIED。格式、哈希定义及旧包兼容见 [证据包格式与重放](docs/05_测试/证据包格式与重放.md)。

## Web 可视化工作台

零构建（vanilla JS）的可视化界面，把上述命令封装为按钮操作：

```bash
pip install -e .[web]
python scripts/start_web.py
# 打开 http://127.0.0.1:8000/；保持服务进程运行
```

`start_web.py` 显式读取五项 LLM 配置（进程环境 > `.env` > 本地默认值），并从项目根目录启动。它与直接运行 uvicorn 的配置行为不同。

注意：`http://127.0.0.1:11434/v1` 是模型 API 根地址，直接用浏览器打开可能返回 404；工作台页面是 `http://127.0.0.1:8000/`。可用 `http://127.0.0.1:11434/v1/models` 检查模型列表，它不是工作台。

提供：仓库选择/导入、索引构建、Issue 定位与修改计划、完整闭环（自动补丁 + 测试验证 +
Markdown 报告下载、证据包重放）、评测集指标、合规披露、评测集挖掘，以及 LLM / 语义向量环境状态提示。

## 目录与阅读入口

```text
replens/       核心索引、检索、补丁、执行、验收与报告
web/           可选 Web API 与静态前端
tests/         项目自身测试
examples/      演示仓库与仓库外的独立验收材料
eval/          评测脚本及 datasets/training/mined/reference_patches
scripts/       数据准备、训练与辅助校验脚本
reports/       demos/experiments/compliance/archive 与后续 runs 输出
docs/          按需求、架构、接口、测试、运维归类的文档
project-os/    当前状态、维护决策、历史任务与验收证据
```

- 当前完成情况与验证边界：[项目状态](project-os/项目状态.md)。
- 后续任务与验收条件：[ROADMAP](ROADMAP.md)。
- 文档导航：[文档地图](docs/文档地图.md)。
- 数据用途与使用命令：[评测材料索引](eval/README.md)。
- 当前可查报告与历史材料：[报告索引](reports/README.md)。

## 模型配置与启动

本次正式归档 Demo 实际使用 Ollama 标签 `qwen2.5-coder:1.5b`，本机 ID `db848539a068`，GGUF、Q4_K_M，约 1.1 GB。5 份原始请求及响应中的模型名均一致（计划 1 次、补丁 4 次）；本机另两个模型仅能证明已安装，没有它们参与该次 Demo 的调用证据。此处 1.5B 是模型名称的一部分，不用本地元数据的参数规模标签推导效果；未使用本项目训练脚本生成的权重。

模型身份与来源边界详见[本地模型说明](docs/02_架构/本地模型.md)。

普通 CLI 和直接运行 uvicorn 的 Web **不会自动读取 `.env`**。在 Windows PowerShell 中，先在项目根目录设置：

```powershell
$env:REPLENS_LLM_BASE_URL = 'http://127.0.0.1:11434/v1'
$env:REPLENS_LLM_MODEL = 'qwen2.5-coder:1.5b'
$env:REPLENS_LLM_N_CANDIDATES = '4'
$env:REPLENS_REQUIRE_LLM = '1'
$env:REPLENS_LLM_PROVIDER = ''
$env:REPLENS_LLM_API_KEY = ''
Remove-Item Env:OPENAI_API_KEY -ErrorAction SilentlyContinue
python scripts/llm_env.py
python -m uvicorn web.app:app --host 127.0.0.1 --port 8000
```

本地服务需已经启动且安装了指定模型。上述变量仅作用于当前终端及随后启动的子进程。
GET `/models` 自检或 Web“已配置”都不表示推理已经成功；需要实际运行计划/修复确认。
完整的 CLI、Web、`.env`、兼容接口与离线切换步骤见 [模型配置与启动](docs/06_运维/模型配置与启动.md)。

正式 Demo 证据使用 `python scripts/run_llm_demo.py`。该脚本可以读取 `.env`，始终禁止规则兜底，
通过标准 CLI `run` / `verify` 保存调用轨迹、实际调用/重试次数、源码快照和重放结果。
可用 `--output-dir <新目录>` 指定交付位置，已有目录不覆盖，详见 [LLM 证据说明](reports/llm/README.md)。
云端或自建兼容服务使用同一组 `REPLENS_*` 环境变量，地址、模型名和 key 按实际服务填写。
未配置地址且允许回退时，普通入口使用有限规则；严格模式不会把规则补丁记为模型成功。

## 当前效果与验证边界

当前结果统一见[提交事实与证据](docs/05_测试/提交事实与证据.md)：235项测试、81子测试通过；Demo文件hit@5=0.95、函数短名@5=0.85（20个正向描述、5个干扰）。grep文件hit@5更高，RepoLens首位和MRR较高；本轮调用图消融无指标变化，未运行向量组。

严格模型Demo的计划和补丁均来自模型，独立验收与重放通过；真实tqdm reset(inf)验证的是上游Gold，不计模型自主修复。136个定位正向描述和112个修复候选条目不是模型成功修复数量。本轮已补齐工作台首页与模型计划的实际浏览器检查，Word/PDF已生成；完整浏览器修复/重放流程、完整Web/模型新环境及跨机器交付、视频和最终发布仍需单独完成。

## 文档

- 系统设计与技术选型：[docs/02_架构/设计方案.md](docs/02_架构/设计方案.md)
- 核验标准与验收效果：[docs/05_测试/验收规划.md](docs/05_测试/验收规划.md)

- 可编辑报告：[Word](docs/02_架构/技术报告.docx)；对应[PDF](docs/02_架构/技术报告.pdf)（含49项资源核验清单，4项仍待确认）。
- [项目目录与发布说明](docs/06_运维/项目目录与发布说明.md)。

- [第三方资源清单](reports/compliance/open_source_checklist.md)与[开放边界](THIRD_PARTY_NOTICES.md)：42项已核验、4项待确认、3项本轮不适用。
