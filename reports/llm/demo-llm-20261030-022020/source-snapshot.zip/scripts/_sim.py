import sys, types
fake = types.ModuleType('typing_extensions'); fake.__version__='4.11.0'
sys.modules['typing_extensions']=fake
import importlib
importlib.reload
import subprocess