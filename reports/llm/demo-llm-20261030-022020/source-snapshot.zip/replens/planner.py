"""修改计划生成。

基于检索到的证据，生成结构化修改计划：
问题原因分析、影响范围、修改文件列表、修改步骤、风险提示、回归测试。

两种实现：
- RulePlanner：零 key 兜底，用模板 + 证据拼装，保证离线可跑。
- LLMPlanner：注入证据上下文，让 LLM 生成更高质量的计划；失败时回退到 RulePlanner。
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from typing import List, Optional

from .retriever import Evidence


@dataclass
class Plan:
    root_cause: str = ""
    affected_scope: List[str] = field(default_factory=list)
    files_to_modify: List[str] = field(default_factory=list)
    steps: List[str] = field(default_factory=list)
    risks: List[str] = field(default_factory=list)
    regression_test: str = ""
    generated_by: str = "rule"  # rule / llm

    def to_dict(self) -> dict:
        return asdict(self)


class Planner:
    def generate(self, issue: str, evidences: List[Evidence]) -> Plan:
        raise NotImplementedError


def _llm_required() -> bool:
    return os.environ.get("REPLENS_REQUIRE_LLM", "").lower() in {"1", "true", "yes"}


class RulePlanner(Planner):
    """规则兜底：不依赖 LLM，基于证据拼装计划。"""

    def generate(self, issue: str, evidences: List[Evidence]) -> Plan:
        if not evidences:
            return Plan(
                root_cause="证据不足，无法确认问题根因。",
                affected_scope=[],
                files_to_modify=[],
                steps=["补充问题描述或确认目标仓库是否包含相关代码。"],
                risks=["无依据推断风险"],
                regression_test="",
                generated_by="rule",
            )

        top = evidences[0].symbol
        files = sorted({e.symbol.path for e in evidences})
        funcs = [e.symbol for e in evidences if e.symbol.type in ("function", "method")]

        root_cause = (
            f"根据检索证据，问题最可能位于 {top.path}:{top.start_line} "
            f"的 {top.type} `{top.name}`。"
        )
        if top.signature:
            root_cause += f" 签名：`{top.signature}`。"
        elif funcs and funcs[0].signature:
            root_cause += f" 签名：`{funcs[0].signature}`。"

        # 追加证据代码首行，便于人工快速复核根因
        if top.code:
            code_lines = top.code.splitlines()
            if code_lines:
                first_line = code_lines[0].strip()
                if first_line:
                    root_cause += f" 关键代码：`{first_line[:120]}`。"

        steps = [
            f"阅读 {top.path} 第 {top.start_line}-{top.end_line} 行的实现。",
        ]
        if funcs:
            steps.append(f"确认 `{funcs[0].name}` 的输入边界条件与现有测试覆盖。")
        steps.append("在临时副本中应用候选修改并运行白名单测试。")

        risks = [
            "本计划由规则模板生成，未经过大模型语义推理，需人工复核。",
            "仅覆盖检索到的局部证据，可能遗漏相关调用方。",
        ]

        return Plan(
            root_cause=root_cause,
            affected_scope=files,
            files_to_modify=files,
            steps=steps,
            risks=risks,
            regression_test=self._build_test_hint(evidences),
            generated_by="rule",
        )

    @staticmethod
    def _build_test_hint(evidences: List[Evidence]) -> str:
        funcs = [e.symbol for e in evidences if e.symbol.type in ("function", "method")]
        if not funcs:
            return ""
        f = funcs[0]
        return (
            f"# 建议在测试中覆盖 `{f.name}` 的边界输入（如空字符串、带空格、None 等）。\n"
            f"# 目标文件: {f.path} 函数定义位于第 {f.start_line} 行。"
        )


class LLMPlanner(Planner):
    """LLM 生成计划，失败回退 RulePlanner。"""

    def __init__(self, llm, model: str = "gpt-4o-mini"):
        self.llm = llm
        self.model = model
        self.fallback = RulePlanner()

    def _fail(self, issue: str, evidences: List[Evidence], reason: str) -> Plan:
        if _llm_required():
            raise RuntimeError("严格模式：禁止规则回退。" + reason)
        return self.fallback.generate(issue, evidences)

    def generate(self, issue: str, evidences: List[Evidence]) -> Plan:
        if not evidences:
            return self.fallback.generate(issue, evidences)

        system = (
            "你是开源贡献辅助工具。基于给定的代码证据生成结构化修改计划。"
            "只允许引用提供的证据，不得编造不存在的文件或行号。"
            "严格输出 JSON，字段：root_cause(字符串)、affected_scope(数组)、"
            "files_to_modify(数组)、steps(数组)、risks(数组)、regression_test(字符串)。"
        )
        ctx_lines = []
        for e in evidences[:10]:
            numbered = "\n".join(
                f"{e.symbol.start_line + i:04d} | {line}"
                for i, line in enumerate(e.symbol.code.splitlines()[:60])
            )
            ctx_lines.append(
                f"- evidence={e.symbol.ref} ({e.symbol.type} {e.symbol.name}): {e.reason}\n"
                f"[代码]\n{numbered}\n[/代码]"
            )
        user = (
            f"问题描述：{issue}\n\n"
            f"检索到的代码证据：\n" + "\n".join(ctx_lines)
        )

        try:
            data = self.llm.chat_json(system, user)
        except Exception as e:
            return self._fail(issue, evidences, "LLM 调用异常: " + str(e))
        if not data:
            return self._fail(issue, evidences, "LLM 返回空响应")
        if not isinstance(data, dict):
            return self._fail(issue, evidences, "LLM 返回不是 JSON 对象")
        evidence_paths = {e.symbol.path for e in evidences}
        as_text = lambda value: value if isinstance(value, str) else ""
        as_list = lambda value: [x for x in value if isinstance(x, str)] if isinstance(value, list) else []
        affected = as_list(data.get("affected_scope", []))
        files = [p for p in as_list(data.get("files_to_modify", [])) if p in evidence_paths]
        if not as_text(data.get("root_cause")) or not files:
            return self._fail(issue, evidences, "LLM 返回缺少 root_cause 或有效 files_to_modify")
        return Plan(
            root_cause=as_text(data.get("root_cause")),
            affected_scope=[p for p in affected if p in evidence_paths],
            files_to_modify=files,
            steps=as_list(data.get("steps", [])),
            risks=as_list(data.get("risks", [])),
            regression_test=as_text(data.get("regression_test", "")),
            generated_by="llm",
        )


def build_planner() -> Planner:
    """根据环境变量构建 planner。

    - 设置了 OPENAI_BASE_URL / OPENAI_API_KEY 时用 LLMPlanner
    - 否则用 RulePlanner 兜底
    """
    base = os.environ.get("REPLENS_LLM_BASE_URL") or os.environ.get("OPENAI_BASE_URL")
    key = os.environ.get("REPLENS_LLM_API_KEY") or os.environ.get("OPENAI_API_KEY") or ""
    if base:
        from .llm import OpenAICompatLLM
        # 本地 Ollama 无需 key；未显式指定模型时按 base_url 自动选择
        is_local = ("11434" in base or "localhost" in base)
        default_model = "qwen2.5-coder:1.5b" if is_local else "gpt-4o-mini"
        model = os.environ.get("REPLENS_LLM_MODEL", default_model)
        client = OpenAICompatLLM(base, key, model=model, use_response_format=is_local,
                                 purpose="plan")
        return LLMPlanner(client, model=model)
    if _llm_required():
        raise RuntimeError("REPLENS_REQUIRE_LLM=1，但未配置 REPLENS_LLM_BASE_URL 或 OPENAI_BASE_URL")
    return RulePlanner()
